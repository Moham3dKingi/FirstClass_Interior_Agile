# FirstClass_Interior_Agile

Project First Class Interiors

During this project we intend to do what ever we can to improve the website during creating and we have a team of peoeple who will help produce this website, we will use the wireframe made by our designer as a base and foundation as we improve on the website as we go.

For this project we are creating a interior design website to help advertise the amazing interior desgins for many different types of builds and infrastructure for our employer.

Our company name: Smith private Limited
